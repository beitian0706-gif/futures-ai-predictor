from datetime import datetime,timedelta
from research import Bar,ResearchInput,study
bars=[Bar(timestamp=datetime(2026,1,1)+timedelta(hours=i),open=100,high=115,low=95,close=100 if i<150 else 110,volume=100) for i in range(200)]
r=study(ResearchInput(symbol='RB2701',bars=bars))
assert r['signal_count']==1 and r['signals'][0]['direction']=='up'
print('MA144 cross test passed')
