"""Offline, auditable 60-minute signal research; no order execution."""
from typing import Literal
from pydantic import BaseModel, Field
from datetime import datetime
import math

class Bar(BaseModel):
    timestamp: datetime
    open: float = Field(gt=0)
    high: float = Field(gt=0)
    low: float = Field(gt=0)
    close: float = Field(gt=0)
    volume: float = Field(ge=0)
    open_interest: float | None = Field(default=None, ge=0)

class ResearchInput(BaseModel):
    symbol: str = Field(min_length=2, max_length=30)
    timeframe: Literal['60m'] = '60m'
    bars: list[Bar] = Field(min_length=145, max_length=20000)
    horizon: int = Field(default=5, ge=1, le=60)

def study(req: ResearchInput):
    bars=req.bars
    times=[b.timestamp for b in bars]
    if any(b<=a for a,b in zip(times,times[1:])):
        raise ValueError('K线时间必须严格递增，不允许重复')
    for b in bars:
        if b.high < max(b.open,b.close,b.low) or b.low > min(b.open,b.close,b.high):
            raise ValueError('K线OHLC不合法')
    closes=[b.close for b in bars]
    ma=[]
    running=sum(closes[:144])
    for i in range(143,len(closes)):
        if i>143: running+=closes[i]-closes[i-144]
        ma.append(running/144)
    signals=[]
    for i in range(144,len(closes)):
        prev=ma[i-144]; curr=ma[i-143]
        direction='up' if closes[i-1]<=prev and closes[i]>curr else 'down' if closes[i-1]>=prev and closes[i]<curr else None
        if direction:
            forward=(closes[i+req.horizon]/closes[i]-1) if i+req.horizon<len(closes) else None
            # Outcome measured after signal close; excludes costs, slippage, gaps and contract rolls.
            signals.append({'timestamp':times[i].isoformat(),'direction':direction,'close':closes[i], 'ma144':round(curr,6),'forward_return':round(forward,6) if forward is not None else None,'favorable':(forward>0 if direction=='up' else forward<0) if forward is not None else None})
    completed=[s for s in signals if s['favorable'] is not None]
    successes=sum(s['favorable'] for s in completed)
    return {'symbol':req.symbol,'timeframe':'60m','bars':len(bars),'last_close':closes[-1], 'last_ma144':round(ma[-1],6),'last_bar':times[-1].isoformat(),'signals':signals[-100:],'signal_count':len(signals),'evaluated_count':len(completed),'favorable_rate':round(successes/len(completed),4) if completed else None,'horizon_bars':req.horizon,'method':'收盘价相对MA144的严格跨越；结果以信号收盘价为基准','warning':'仅离线研究；数据需自行核验。胜率不是盈利率；未计交易成本、滑点、换月及未来数据泄漏检查；不自动下单。'}
