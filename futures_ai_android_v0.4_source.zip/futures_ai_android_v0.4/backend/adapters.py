"""Extension contract for future exchanges and market data providers."""
from typing import Protocol
from dataclasses import dataclass

@dataclass(frozen=True)
class Instrument:
    market: str
    exchange: str
    product: str
    contract: str
    currency: str
    timezone: str

class MarketProvider(Protocol):
    def list_contracts(self, product: str) -> list[Instrument]: ...
    def get_bars(self, contract: str, timeframe: str, limit: int) -> list[dict]: ...

MARKETS={
    'CN': {'status':'partial','currency':'CNY','timezone':'Asia/Shanghai','exchanges':['SHFE','DCE','CZCE','GFEX','CFFEX']},
    'US': {'status':'planned','currency':'USD','timezone':'America/Chicago','exchanges':['CME','ICE_US']},
    'EU': {'status':'planned','currency':'EUR','timezone':'Europe/Berlin','exchanges':['EUREX','ICE_EU']}
}
