# 期货智研 AI V0.2

中国期货行情数据接入 + 移动端适配 Web APP 原型。**不是 Android APK，也不提供已验证的价格预测**。

## Windows 启动

解压 ZIP，进入 `futures_ai_app_v0.2` 文件夹，在 PowerShell 中执行：

```powershell
py -m venv .venv
.\.venv\Scripts\python.exe -m pip install -r requirements.txt
.\.venv\Scripts\python.exe -m uvicorn main:app --host 127.0.0.1 --port 8000
```

打开 http://127.0.0.1:8000 ，手机在同一网络访问需要自行调整监听地址与防火墙，**不要将开发服务直接暴露到公网**。

## 功能

- `GET /contracts?product=螺纹钢`：通过 AKShare 的新浪期货接口获取合约并按持仓量选择**候选**主力（不以连续合约代替）。
- `GET /candles/RBxxxx`：查询所选具体合约历史日线；真实代码以接口返回为准。
- `POST /analyze-contract`：技术面 + 资金代理分析；未接入基本面与新闻时相应因子缺失，不虚构评分。
- `POST /analyze`：保留 V0.1 的外部K线输入接口。
- `GET /markets`：中国已接入、全球待扩展的市场清单。

## 重要限制

- 第三方数据源可能改变字段、限流、停用或延迟；当前环境无法验证联网接口可用性，需在本地测试。
- 候选主力按单次持仓量排序，尚未建立交易所日历、换月规则、合约到期和异常过滤；用户必须核验。
- 日线不支持60分钟MA144即时提醒。该功能列入下一迭代。
- 资金因子仅用量仓变化，不等于资金净流入。基本面、情绪面尚未自动采集。
- 情景区间由历史波动率计算，未回测校准；综合评分不是上涨概率。
- 本版无数据库、用户登录、推送、安卓原生包、交易接口；不自动下单。
