from fastapi import FastAPI, HTTPException
from fastapi.responses import FileResponse
from fastapi.staticfiles import StaticFiles
from pydantic import BaseModel
from pathlib import Path
from datetime import datetime
import math
from engine import AnalysisRequest, Candle, analyze as run_analysis

ROOT=Path(__file__).parent
app=FastAPI(title='期货智研 AI',version='0.3.0')
app.mount('/static',StaticFiles(directory=ROOT/'static'),name='static')

@app.get('/')
def home(): return FileResponse(ROOT/'static'/'index.html')

@app.get('/health')
def health(): return {'status':'ok','version':'0.3.0'}

@app.get('/markets')
def markets():
    return {'enabled':['CN'],'planned':['US','EU'],'providers':['akshare_sina','csv'],'note':'全球市场接口预留，未接入'}

@app.get('/contracts')
def contracts(product: str='螺纹钢'):
    try:
        import akshare as ak
        df=ak.futures_zh_realtime(symbol=product)
        if df is None or df.empty: raise ValueError('未返回合约')
        rows=df.where(df.notna(),None).to_dict('records')
        def pick(row,*names):
            for n in names:
                if n in row and row[n] is not None:return row[n]
            return None
        items=[]
        for r in rows:
            code=pick(r,'symbol','合约代码','代码','contract')
            if not code:continue
            oi=pick(r,'hold','持仓量','open_interest')
            try: oi=float(oi) if oi is not None else None
            except (TypeError,ValueError):oi=None
            items.append({'code':str(code),'name':str(pick(r,'name','名称') or code),'open_interest':oi})
        items.sort(key=lambda x:x['open_interest'] if x['open_interest'] is not None else -1,reverse=True)
        return {'product':product,'contracts':items,'main_candidate':items[0]['code'] if items and items[0]['open_interest'] is not None else None,'method':'按返回持仓量排序的候选主力；需核对交易所及日期','source':'AKShare/Sina','as_of':datetime.now().isoformat(timespec='seconds')}
    except ImportError: raise HTTPException(503,'尚未安装 akshare，请执行 pip install -r requirements.txt')
    except Exception as e: raise HTTPException(502,f'行情源暂不可用：{type(e).__name__}: {str(e)[:160]}')

@app.get('/candles/{contract}')
def candles(contract:str, limit:int=180):
    if not 30<=limit<=1000:raise HTTPException(400,'limit必须在30至1000之间')
    if not contract.replace('_','').isalnum():raise HTTPException(400,'无效合约代码')
    try:
        import akshare as ak
        df=ak.futures_zh_daily_sina(symbol=contract)
        if df is None or df.empty:raise ValueError('无日线数据')
        df=df.tail(limit)
        out=[]
        for _,r in df.iterrows():
            def get(*keys):
                for k in keys:
                    if k in r:return r[k]
                return None
            oi=get('hold','open_interest','持仓量')
            def number(v):
                try:
                    f=float(v)
                    return f if math.isfinite(f) else None
                except (TypeError,ValueError):return None
            row={'timestamp':str(get('date','日期'))[:10],'open':number(get('open','开盘价')),'high':number(get('high','最高价')),'low':number(get('low','最低价')),'close':number(get('close','收盘价')),'volume':number(get('volume','成交量')),'open_interest':number(oi)}
            if all(row[k] is not None for k in ('open','high','low','close','volume')):out.append(row)
        if len(out)<30:raise ValueError('有效K线不足30根')
        return {'contract':contract,'timeframe':'1d','source':'AKShare/Sina','retrieved_at':datetime.now().isoformat(timespec='seconds'),'candles':out,'delayed_or_realtime':'历史日线，非实时推送'}
    except ImportError:raise HTTPException(503,'尚未安装 akshare')
    except Exception as e:raise HTTPException(502,f'日线数据不可用：{type(e).__name__}: {str(e)[:160]}')

@app.post('/analyze')
def analyze(req:AnalysisRequest):return run_analysis(req)

class ContractAnalysis(BaseModel):
    contract:str
    fundamental_score:float|None=None
    sentiment_score:float|None=None

@app.post('/analyze-contract')
def analyze_contract(req:ContractAnalysis):
    data=candles(req.contract)
    payload=AnalysisRequest(symbol=req.contract,candles=[Candle(**x) for x in data['candles']],fundamental_score=req.fundamental_score,sentiment_score=req.sentiment_score)
    result=run_analysis(payload)
    result['source']=data['source'];result['timeframe']='1d';result['retrieved_at']=data['retrieved_at'];result['data_note']='基本面与情绪评分如未输入，则不参与评分；资金面仅使用持仓量及成交量代理指标。'
    return result

# V0.3: reproducible 60m research, not a live signal service.
from research import ResearchInput, study
from adapters import MARKETS
from fastapi import UploadFile, File
from io import StringIO
import csv

app.version='0.3.0'

@app.get('/v3/markets')
def market_registry(): return MARKETS

@app.post('/v3/research')
def research(req: ResearchInput):
    try: return study(req)
    except ValueError as e: raise HTTPException(422,str(e))

@app.post('/v3/research-csv')
async def research_csv(file: UploadFile = File(...), symbol: str = 'RB2701', horizon: int = 5):
    if not 1 <= horizon <= 60: raise HTTPException(422,'horizon必须为1至60')
    raw=await file.read(4_000_001)
    if len(raw)>4_000_000: raise HTTPException(413,'CSV最大4MB')
    try:
        from research import Bar
        content=raw.decode('utf-8-sig')
        reader=csv.DictReader(StringIO(content))
        required={'timestamp','open','high','low','close','volume'}
        if not reader.fieldnames or not required.issubset(reader.fieldnames):
            raise ValueError('CSV必须包含 timestamp,open,high,low,close,volume 列')
        bars=[]
        for row in reader:
            if len(bars)>=20000: raise ValueError('最多20000根K线')
            row={k:v for k,v in row.items() if k in required|{'open_interest'} and v not in ('',None)}
            bars.append(Bar(**row))
        return study(ResearchInput(symbol=symbol,bars=bars,horizon=horizon))
    except (ValueError, UnicodeError) as e: raise HTTPException(422,str(e)[:300])
    except Exception as e: raise HTTPException(422,f'CSV格式错误: {type(e).__name__}: {str(e)[:150]}')
