from fastapi import FastAPI, HTTPException
from pydantic import BaseModel, Field
from typing import List, Optional
import numpy as np

app = FastAPI(title='期货智研 AI', version='0.1.0')

class Candle(BaseModel):
    timestamp: str
    open: float
    high: float
    low: float
    close: float = Field(gt=0)
    volume: float = Field(ge=0)
    open_interest: Optional[float] = Field(default=None, ge=0)

class AnalysisRequest(BaseModel):
    symbol: str
    candles: List[Candle] = Field(min_length=30)
    fundamental_score: Optional[float] = Field(default=None, ge=-1, le=1)
    sentiment_score: Optional[float] = Field(default=None, ge=-1, le=1)

def ema(values, span):
    alpha = 2/(span+1)
    result = float(values[0])
    for value in values[1:]:
        result = alpha*float(value)+(1-alpha)*result
    return result

@app.get('/health')
def health():
    return {'status':'ok', 'version':'0.1.0'}

@app.post('/analyze')
def analyze(req: AnalysisRequest):
    c = np.array([x.close for x in req.candles], dtype=float)
    v = np.array([x.volume for x in req.candles], dtype=float)
    returns = np.diff(np.log(c))
    if not np.all(np.isfinite(returns)):
        raise HTTPException(400, 'Invalid price data')
    fast, slow = ema(c, 12), ema(c, 26)
    ma20 = float(np.mean(c[-20:]))
    trend = float(np.tanh(((fast-slow)/c[-1])*30 + ((c[-1]/ma20)-1)*10))
    vol_ratio = float(v[-5:].mean()/max(v[-20:].mean(), 1e-9))
    oi = [x.open_interest for x in req.candles]
    oi_change = None
    if oi[-6] is not None and oi[-1] is not None and oi[-6] > 0:
        oi_change = (oi[-1]-oi[-6])/oi[-6]
    flow = float(np.tanh((vol_ratio-1)*0.6 + (oi_change or 0)*5)) if oi_change is not None else None
    factors = {'technical':trend,'capital':flow,'fundamental':req.fundamental_score,'sentiment':req.sentiment_score}
    weights = {'technical':0.4,'capital':0.25,'fundamental':0.25,'sentiment':0.1}
    present = {k:val for k,val in factors.items() if val is not None}
    total_weight = sum(weights[k] for k in present)
    score = sum(weights[k]*val for k,val in present.items())/total_weight
    # Scenario range is based on observed volatility, not a validated predictive interval.
    daily_vol = float(np.std(returns[-min(len(returns),20):], ddof=1))
    horizons = {}
    for h in (1,5,20):
        sigma = daily_vol*np.sqrt(h)
        horizons[str(h)] = {'lower_scenario':round(float(c[-1]*np.exp(-1.28*sigma)),4),'upper_scenario':round(float(c[-1]*np.exp(1.28*sigma)),4)}
    return {'symbol':req.symbol,'last_price':float(c[-1]),'factor_scores':factors,'combined_score':round(score,3),'bias':'bullish' if score>0.2 else 'bearish' if score < -0.2 else 'neutral','ma20':round(ma20,4),'ema12':round(fast,4),'ema26':round(slow,4),'volume_ratio':round(vol_ratio,3),'open_interest_change':oi_change,'scenario_ranges':horizons,'data_coverage':list(present),'warning':'研究原型；并非实时行情、校准概率或投资建议。周期按输入K线计，不自动等于交易日。'}
