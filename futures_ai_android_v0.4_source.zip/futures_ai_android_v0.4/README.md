# 期货智研 AI Android V0.4

这是 **Android Studio 可编译源码项目**，不是已编译 APK。Android 端采用本地 HTML + WebView UI，调用随包附带的 Python FastAPI 后端。手机端不能独立采集行情，必须有可访问的后端服务器。

## 获取 APK

**方法A（推荐）**：安装 Android Studio，打开本目录（包含 settings.gradle），等待 Gradle 同步完成，选择 Build > Build APK(s)，生成 `app/build/outputs/apk/debug/app-debug.apk`。

**方法B**：将本目录推送到个人 GitHub 仓库 main 分支，在 Actions 中运行 Build Android APK，下载 `futures-ai-v0.4-debug-apk` 构建产物。请注意 GitHub Actions 工作流必须存在于仓库 `.github/workflows` 中。

构建需要 Android SDK 35、Java 17、Gradle 8.9。当前生成环境没有 Android SDK/Gradle，因此未能验证 APK 实际编译和手机运行。

## 启动后端（Windows）

在 `backend` 目录打开 PowerShell：

```powershell
py -m venv .venv
.\.venv\Scripts\python.exe -m pip install -r requirements.txt
.\.venv\Scripts\python.exe -m uvicorn main:app --host 0.0.0.0 --port 8000
```

将电脑和手机连接同一可信 Wi-Fi，查询电脑的局域网 IPv4 地址（`ipconfig`），在手机 APP 中填入 `http://电脑IP:8000`，检测连接。可能需要允许 Windows 防火墙局域网入站 8000 端口。不要将该开发服务器直接暴露公网。发布生产版应使用 HTTPS、鉴权、访问限制，并禁用明文流量。

## 当前限制

- 实际行情依赖 AKShare/Sina 外部接口；未在当前环境验证连通性。
- 主力候选仅按持仓量排序；不保证正确，不能用连续合约代替。
- 分析以历史日线为主；基本面、新闻与实时60分钟行情尚未自动接入。
- UI为原生 Android 容器承载的本地 Web 页面，不是全原生 Compose UI。
- 不自动下单，不提供经过校准的上涨概率。
